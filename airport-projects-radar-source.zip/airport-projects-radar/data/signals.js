window.AMI_SIGNALS = {
    "generated":  "2026-09-12T00:06:37+03:00",
    "dismissed":  [
                      "https://mediacentre.heathrow.com/pressrelease/detail/26018"
                  ],
    "projects":  {
                     "AP-SG-SIN-T5":  [
                                          {
                                              "title":  "DHL to open healthcare logistics center at Changi Airport",
                                              "link":  "https://www.passengerterminaltoday.com/news/operations-news/dhl-to-open-healthcare-logistics-center-at-changi-airport.html",
                                              "published":  "Mon, 07 Sep 2026 13:37:35 +0000",
                                              "source":  "Passenger Terminal Today",
                                              "first_seen":  "2026-09-11"
                                          },
                                          {
                                              "title":  "The Changi experience: Inside one of aviation’s most recognised brands",
                                              "link":  "https://www.internationalairportreview.com/the-changi-experience-inside-one-of-aviations-most-recognised-brands/1671478.article",
                                              "published":  "",
                                              "source":  "International Airport Review (homepage)",
                                              "first_seen":  "2026-09-11"
                                          }
                                      ],
                     "EU-DE-FRA-T3":  [
                                          {
                                              "title":  "VIDEO: How Frankfurt Airport’s Terminal 3 blends art and retail to reshape passenger experience",
                                              "link":  "https://www.passengerterminaltoday.com/videos/video-how-frankfurt-airports-terminal-3-blends-art-and-retail-to-reshape-passenger-experience.html",
                                              "published":  "Wed, 09 Sep 2026 13:48:00 +0000",
                                              "source":  "Passenger Terminal Today",
                                              "first_seen":  "2026-09-11"
                                          },
                                          {
                                              "title":  "The energy transition at Frankfurt Airport: A Q\u0026A with Michelle Sandbrink, Corporate Strategy and Sustainability Management at Fraport AG",
                                              "link":  "https://www.internationalairportreview.com/sustainability-and-net-zero/the-energy-transition-at-frankfurt-airport-a-qanda-with-michelle-sandbrink-corporate-strategy-and-sustainability-management-at-fraport-ag/2135312.article",
                                              "published":  "",
                                              "source":  "International Airport Review (homepage)",
                                              "first_seen":  "2026-09-11"
                                          },
                                          {
                                              "title":  "Passenger numbers rise across Fraport’s global airport network",
                                              "link":  "https://airport-world.com/passenger-numbers-rise-across-fraports-global-airport-network/?utm_source=rss\u0026utm_medium=rss\u0026utm_campaign=passenger-numbers-rise-across-fraports-global-airport-network",
                                              "published":  "Fri, 11 Sep 2026 09:36:42 +0000",
                                              "source":  "Airport World",
                                              "first_seen":  "2026-09-11"
                                          }
                                      ],
                     "NA-US-DFW-TF":  [
                                          {
                                              "title":  "IAG, DFW, All Nippon Airways, MUC, Turkish Airlines and Japan Airport Terminal among winners in FTE Global Pioneer Awards 2026",
                                              "link":  "https://www.futuretravelexperience.com/2026/09/iag-dfw-all-nippon-airways-muc-turkish-airlines-and-japan-airport-terminal-among-winners-in-fte-global-pioneer-awards-2026/",
                                              "published":  "Wed, 09 Sep 2026 03:56:40 +0000",
                                              "source":  "Future Travel Experience",
                                              "first_seen":  "2026-09-12"
                                          }
                                      ],
                     "NA-US-ORD-TAP":  [
                                           {
                                               "title":  "World’s busiest airports revealed in latest global rankings",
                                               "link":  "https://aci.aero/2026/04/14/worlds-busiest-airports-revealed-in-latest-global-rankings/",
                                               "published":  "Tue, 14 Apr 2026 11:35:28 +0000",
                                               "source":  "ACI World",
                                               "first_seen":  "2026-09-12"
                                           }
                                       ],
                     "ME-JO-AMM-EXP":  [
                                           {
                                               "title":  "Queen Alia International seeks new concessions for expansion",
                                               "link":  "https://www.passengerterminaltoday.com/news/food-beverage/queen-alia-international-seeks-new-concessions-for-expansion.html",
                                               "published":  "Wed, 09 Sep 2026 14:11:56 +0000",
                                               "source":  "Passenger Terminal Today",
                                               "first_seen":  "2026-09-11"
                                           }
                                       ],
                     "NA-US-PIT-TMP":  [
                                           {
                                               "title":  "Inside Pittsburgh International Airport’s transformation: CEO Christina Cassotis on building resilience for the future",
                                               "link":  "https://www.internationalairportreview.com/inside-pittsburgh-international-airports-transformation-ceo-christina-cassotis-on-building-resilience-for-the-future/2136386.article",
                                               "published":  "",
                                               "source":  "International Airport Review (homepage)",
                                               "first_seen":  "2026-09-12"
                                           },
                                           {
                                               "title":  "Redefining what it means to be an airport: Pittsburgh Airport CEO, Christina Cassotis",
                                               "link":  "https://www.internationalairportreview.com/redefining-what-it-means-to-be-an-airport-pittsburgh-airport-ceo-christina-cassotis/2136377.article",
                                               "published":  "",
                                               "source":  "International Airport Review (homepage)",
                                               "first_seen":  "2026-09-12"
                                           },
                                           {
                                               "title":  "Pittsburgh International Airport introduces first-ever video gaming lounge to enhance CX",
                                               "link":  "https://www.futuretravelexperience.com/2026/08/pittsburgh-international-airport-introduces-first-ever-video-gaming-lounge-to-enhance-cx/",
                                               "published":  "Sun, 30 Aug 2026 11:21:35 +0000",
                                               "source":  "Future Travel Experience",
                                               "first_seen":  "2026-09-12"
                                           }
                                       ],
                     "EU-GB-LHR-R3":  [

                                      ],
                     "EU-LV-RIX-TERM":  [
                                            {
                                                "title":  "Refuelling options increase at Lithuanian gateways",
                                                "link":  "https://airport-world.com/refuelling-options-increase-at-lithuanian-gateways/?utm_source=rss\u0026utm_medium=rss\u0026utm_campaign=refuelling-options-increase-at-lithuanian-gateways",
                                                "published":  "Wed, 09 Sep 2026 10:13:58 +0000",
                                                "source":  "Airport World",
                                                "first_seen":  "2026-09-11"
                                            }
                                        ],
                     "ME-SA-JED-KAIA":  [
                                            {
                                                "title":  "Saudi Arabia’s King Abdulaziz Airport earns ACI Level 4 customer experience accreditation",
                                                "link":  "https://www.passengerterminaltoday.com/news/passenger-experience/saudi-arabias-king-abdulaziz-airport-earns-aci-level-4-customer-experience-accreditation.html",
                                                "published":  "Tue, 08 Sep 2026 17:03:21 +0000",
                                                "source":  "Passenger Terminal Today",
                                                "first_seen":  "2026-09-11"
                                            }
                                        ]
                 },
    "unmatched":  [

                  ]
};